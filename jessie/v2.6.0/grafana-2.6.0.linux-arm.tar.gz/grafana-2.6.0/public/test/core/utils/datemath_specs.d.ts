declare var _default: {};
export = _default;
