/*! grafana - v2.6.0 - 2016-04-03
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./panel_menu","./panel_directive","./panel_srv","./panel_helper","./solo_panel_ctrl"],function(){});