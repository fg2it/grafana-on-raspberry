/*! grafana - v2.6.0 - 2016-04-03
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

