/// <reference path="../../../../public/app/headers/common.d.ts" />
declare var _default: {
    parse: (text: any, roundUp?: any) => any;
    parseDateMath: (mathString: any, time: any, roundUp?: any) => any;
    isValid: (text: any) => any;
};
export = _default;
