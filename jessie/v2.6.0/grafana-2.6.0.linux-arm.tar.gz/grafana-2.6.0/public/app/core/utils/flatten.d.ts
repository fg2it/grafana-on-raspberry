declare function flatten(target: any, opts: any): any;
export = flatten;
