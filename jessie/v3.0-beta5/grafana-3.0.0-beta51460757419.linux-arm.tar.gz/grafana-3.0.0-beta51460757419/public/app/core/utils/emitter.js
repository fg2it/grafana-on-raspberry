/*! grafana - v3.0.0-beta51460757419 - 2016-04-15
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["eventemitter3"],function(a){var b,c,d;return{setters:[function(a){b=a}],execute:function(){c={}.hasOwnProperty,d=function(){function a(){this.emitter=new b["default"]}return a.prototype.emit=function(a,b){this.emitter.emit(a,b)},a.prototype.on=function(a,b,c){this.emitter.on(a,b),c&&c.$on("$destroy",function(){this.emitter.off(a,b)})},a.prototype.off=function(a,b){this.emitter.off(a,b)},a}(),a("Emitter",d)}}});