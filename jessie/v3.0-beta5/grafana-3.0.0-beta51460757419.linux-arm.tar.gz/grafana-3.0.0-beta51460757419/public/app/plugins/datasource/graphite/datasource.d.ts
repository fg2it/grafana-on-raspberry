/// <reference path="../../../../../public/app/headers/common.d.ts" />
/** @ngInject */
export declare function GraphiteDatasource(instanceSettings: any, $q: any, backendSrv: any, templateSrv: any): void;
