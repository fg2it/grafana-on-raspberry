/// <reference path="../../../../../public/app/headers/common.d.ts" />
declare var _default: {
    create: (part: any) => any;
    getCategories: () => {
        Aggregations: any[];
        Selectors: any[];
        Transformations: any[];
        Math: any[];
        Aliasing: any[];
        Fields: any[];
    };
};
export default _default;
