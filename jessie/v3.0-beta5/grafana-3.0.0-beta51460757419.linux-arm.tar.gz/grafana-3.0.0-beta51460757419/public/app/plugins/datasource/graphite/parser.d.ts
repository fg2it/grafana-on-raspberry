export declare function Parser(expression: any): void;
