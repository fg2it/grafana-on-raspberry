/*! grafana - v2.2.0-pre1 - 2015-09-07
 * Copyright (c) 2015 Torkel Ödegaard; Licensed Apache-2.0 */

define(["angular"],function(a){"use strict";var b=a.module("grafana.directives");b.directive("annotationsQueryEditorElasticsearch",function(){return{templateUrl:"app/plugins/datasource/elasticsearch/partials/annotations.editor.html"}})});