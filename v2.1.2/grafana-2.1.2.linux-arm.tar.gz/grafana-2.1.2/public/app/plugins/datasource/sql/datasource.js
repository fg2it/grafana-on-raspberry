/*! grafana - v2.1.2 - 2015-09-07
 * Copyright (c) 2015 Torkel Ödegaard; Licensed Apache License */

define(["angular","lodash","kbn"],function(a){"use strict";var b=a.module("grafana.services");b.factory("SqlDatasource",function(){function a(){}return a})});